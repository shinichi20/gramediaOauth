# Gramedia Oauth

[![N|Solid](https://www.gramedia.com/blog/content/images/2018/03/Asset-11@20x-100.jpg)](https://www.gramedia.com)

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

Gramedia Oauth is a system for connection to social media

  - Type some Markdown on the left
  - See HTML in the right
  - Magic

# New Features!

  - Connection to milors system

### Installation

Gramedia Oauth2 requires [Django python](https://www.python.org/) v3+ to run.

License
----

MIT


  